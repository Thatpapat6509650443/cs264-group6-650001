package Controller;

import model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Restcontroller{

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public Restcontroller(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    public int save(User cust) {
        return jdbcTemplate.update("INSERT INTO customers (fname, lname, email, dob) VALUES(?,?,?)",
                new Object[] { cust.getFname(),cust.getLname(), cust.getEmail(), cust.getDob() }); }

}