import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import th.ac.tu.cs.assignment.model.CourseRequest;
import th.ac.tu.cs.assignment.repository.CourseRepository;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;

    @PostMapping("/submit")
    public ResponseEntity<String> submitCourseRequest(@RequestBody CourseRequest courseRequest) {
        // ดำเนินการเพิ่มข้อมูลลงในฐานข้อมูล
        courseRepository.save(courseRequest);
        return ResponseEntity.ok("บันทึกข้อมูลสำเร็จ");
    }
}
