package th.ac.tu.cs.services.repository;

import th.ac.tu.cs.services.model.modelRequest;
import java.util.List;
public interface RequestRepository {
    //คำร้อง
    public int save(modelRequest request) ;
    public int update(modelRequest request) ;
    //ที่อย่
    public  int save(modelRequest address);
    public int update(modelRequest address);
    //ต้องการที่จะ
    public  int save(modelRequest Reason);
    public int update(modelRequest Reason);

    //all request
    public  int save(modelRequest allReq);
    public int update(modelRequest allReq);
    //login
    public modelRequest findById(Long id) ;
    public int deleteById(Long id);


    public List<modelRequest> findAll();
}
