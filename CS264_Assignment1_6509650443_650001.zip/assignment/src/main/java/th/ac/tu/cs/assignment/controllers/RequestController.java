//package th.ac.tu.cs.assignment.controllers;
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//import th.ac.tu.cs.assignment.model.Request;
//import th.ac.tu.cs.assignment.repository.RequestRepository;
//
//
//import java.util.List;
//
//
//@RestController
//@RequestMapping("/request")
//public class RequestController {
//
//    @Autowired
//    RequestRepository requestRepository;
//
//    // ดึงข้อมูลทุกรายวิชา
//    @GetMapping
//    public List<Request> getAllCourses() {
//        return requestRepository.findAll();
//    }
//
//    // ดึงข้อมูลรายวิชาจาก ID
//    @GetMapping("/{id}")
//    public Request getCourseById(@PathVariable Long id) {
//        return requestRepository.findById(id);
//    }
//
////    // เพิ่มรายวิชา
////    @PostMapping
////    public Request addCourse(@RequestBody Request course) {
////        return requestRepository.save(course);
////    }
////
////    // อัปเดตข้อมูลรายวิชา
////    @PutMapping("/{id}")
////    public Request updateCourse(@PathVariable Long id, @RequestBody Request updatedCourse) {
////        Request course = requestRepository.findById(id);
////        if (course != null) {
////            course.setCourseCode(updatedCourse.getCourseCode());
////            course.setCourseName(updatedCourse.getCourseName());
////            course.setCredit(updatedCourse.getCredit());
////            return courseRepository.save(course);
////        }
////        return null;
////    }
////
////    // ลบรายวิชาจาก ID
////    @DeleteMapping("/{id}")
////    public void deleteCourse(@PathVariable Long id) {
////        requestRepository.deleteById(id);
////    }
//}
