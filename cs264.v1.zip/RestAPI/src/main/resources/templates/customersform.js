function submitdata() {
    let SirNameInput = document.getElementById('Sirname');
    let SirNameValue = SirNameInput.value;

    let FirstNameDOM = document.querySelector('input[name=Firstname]');
    let LastNameDOM = document.querySelector('input[name=Lastname]');
    let EmaiLDOM = document.querySelector('input[name=Email]');
    let DoBDOM = document.querySelector('input[name=Dob]');

    let userData = {
       sirname: SirNameValue,
        firstname: FirstNameDOM ? FirstNameDOM.value : undefined,
        lastname: LastNameDOM ? LastNameDOM.value : undefined,
        email: EmaiLDOM ? EmaiLDOM.value : undefined,
        dob: DoBDOM ? DoBDOM.value : undefined
    };
    console.log('submit data', userData);
}