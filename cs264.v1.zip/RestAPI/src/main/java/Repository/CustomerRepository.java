package Repository;

import model.User;

public interface CustomerRepository {
    int save(User user);
    int update(User user);
}
