//package th.ac.tu.cs.assignment.repository;
//
//import th.ac.tu.cs.assignment.model.Request;
//
//import java.util.List;
//
//public interface RequestRepository{
////    List<Request> findByStudentId(int studentId); // ค้นหาคำขอตามเลขทะเบียน
////
////    List<Request> findByAdvisor(String advisor); // ค้นหาคำขอตามชื่ออาจารย์ที่ปรึกษา
////
////    List<Request> findByReasonContaining(String keyword); // ค้นหาคำขอตามคำหลักเหตุผล
//
//    List<Request> findAll();
//
//    Request findById(Long id);
//
//}